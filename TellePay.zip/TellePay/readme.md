# TellePay – Agent Bill Payment Platform (Frontend)

TellePay is a modern, agent-focused bill payment platform designed for the Nigerian market.  
This repository contains the **frontend web application** built with **React.js and Tailwind CSS**, showcasing TellePay’s landing page and core service offerings.

The platform focuses primarily on **airtime and mobile data vending**, while also supporting **electricity, cable TV, and other utility payments**, following a POS-style operational model similar to leading Nigerian fintech platforms.

---

## 🚀 Project Overview

TellePay aims to empower agents with:
- Fast and reliable bill payment processing
- Instant commissions and settlements
- High system uptime and fintech-grade security
- A clean, modern interface optimized for daily agent use

This project currently covers the **marketing / landing page UI**, serving as the foundation for future agent dashboards and authentication flows.

---

## 🧱 Tech Stack

- **Framework:** React.js (Vite)
- **Styling:** Tailwind CSS
- **Icons:** Lucide React
- **Font:** Inter (Google Fonts)
- **Language:** JavaScript (ES6+)
- **Architecture:** Component-based UI

---

## 📂 Project Structure

