// JavaScript for TellePay Landing Page

document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.getElementById('hamburger');
    const navbarMenu = document.getElementById('navbarMenu');
    
    // Sticky Navbar on Scroll
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('navbar--scrolled');
        } else {
            navbar.classList.remove('navbar--scrolled');
        }
    });

    // Mobile Menu Toggle
    if (hamburger && navbarMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navbarMenu.classList.toggle('active');
        });

        // Close menu when clicking links
        const navLinks = navbarMenu.querySelectorAll('.navbar__link, .btn');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navbarMenu.classList.remove('active');
            });
        });
    }


    // Smooth Scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerOffset = 80;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Reveal animations on scroll (Optional but adds polish)
    const revealElements = document.querySelectorAll('.service-card, .stat-card, .hero__content, .hero__image-wrapper');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = entry.target.classList.contains('service-card') ? 'translateY(0)' : 'none';
            }
        });
    }, { threshold: 0.1 });

    revealElements.forEach(el => {
        el.style.opacity = '0';
        if (el.classList.contains('service-card')) {
            el.style.transform = 'translateY(20px)';
        }
        el.style.transition = 'all 0.6s ease-out';
        observer.observe(el);
    });

    // Modal Toggle and Countdown Logic
    const agentSignupButtons = document.querySelectorAll('.js-agent-signup');
    const signupModal = document.getElementById('agentSignupModal');
    const modalClose = signupModal?.querySelector('.modal__close');
    const modalOverlay = signupModal?.querySelector('.modal__overlay');
    const timerDisplay = document.getElementById('countdownTimer');
    const progressBar = signupModal?.querySelector('.modal__progress-bar');
    
    const waitlistForm = document.getElementById('waitlistForm');
    const waitlistSuccess = document.getElementById('waitlistSuccess');
    const modalBodyInitial = signupModal?.querySelector('.modal__body > *:not(.modal__success):not(.modal__close)');
    
    // Form Submission Handling
    if (waitlistForm) {
        waitlistForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Simulation of submission
            const submitBtn = waitlistForm.querySelector('button');
            const email = document.getElementById('waitlistEmail')?.value;
            submitBtn.textContent = 'Joining...';
            submitBtn.disabled = true;

            // Persistence logic
            if (email) {
                const waitlist = JSON.parse(localStorage.getItem('tellepay_waitlist') || '[]');
                waitlist.push({
                    email: email,
                    date: new Date().toISOString()
                });
                localStorage.setItem('tellepay_waitlist', JSON.stringify(waitlist));
            }

            setTimeout(() => {
                // Hide timer and form
                if (timerDisplay) timerDisplay.style.display = 'none';
                waitlistForm.style.display = 'none';
                const modalText = signupModal.querySelector('.modal__text');
                if (modalText) modalText.style.display = 'none';
                const modalHeader = signupModal.querySelector('.modal__title');
                if (modalHeader) modalHeader.style.display = 'none';
                const modalIcon = signupModal.querySelector('.modal__icon');
                if (modalIcon) modalIcon.style.display = 'none';

                // Show success
                if (waitlistSuccess) waitlistSuccess.style.display = 'block';
            }, 1000);
        });
    }

    const openModal = () => {
        signupModal?.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Reset modal state
        if (waitlistForm) {
            waitlistForm.style.display = 'flex';
            waitlistForm.reset();
            const submitBtn = waitlistForm.querySelector('button');
            if (submitBtn) {
                submitBtn.textContent = 'Join the Waitlist';
                submitBtn.disabled = false;
            }
        }
        if (waitlistSuccess) waitlistSuccess.style.display = 'none';
        if (timerDisplay) timerDisplay.style.display = 'block';
        
        // Restore hidden elements
        signupModal.querySelectorAll('.modal__body > *:not(.modal__success)').forEach(el => {
            el.style.display = '';
        });
    };

    const closeModal = () => {
        signupModal?.classList.remove('active');
        document.body.style.overflow = '';
    };

    agentSignupButtons.forEach(btn => btn.addEventListener('click', openModal));
    modalClose?.addEventListener('click', closeModal);
    modalOverlay?.addEventListener('click', closeModal);

    // Escape key to close modal
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && signupModal?.classList.contains('active')) {
            closeModal();
        }
    });
});

